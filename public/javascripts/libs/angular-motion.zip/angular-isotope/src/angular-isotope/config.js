angular.module('iso.config', [])
.value('iso.config', {});

angular.module('iso.filters', ['iso.config']);
